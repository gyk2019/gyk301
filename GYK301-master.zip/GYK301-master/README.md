# GYK301
Geleceği Yazan Kadınlar 2019 💪💃
